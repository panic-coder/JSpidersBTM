myapp.controller("resgiterCtr" , function($scope) {
    $scope.message = "hello app";
})