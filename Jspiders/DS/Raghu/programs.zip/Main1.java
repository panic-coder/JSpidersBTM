package TEST;
import java.util.TreeSet;
public class Main1 
{
public static void main(String[] args)
{
	TreeSet ts= new TreeSet(new DscComparator());

	
	
	
}
}
