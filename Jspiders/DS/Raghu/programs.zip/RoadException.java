public class RoadException extends RuntimeException 
{

}
